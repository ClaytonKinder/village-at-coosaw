<?php
			if (!empty ($translate[jt_schedule_startsText])) {
				$starts_text = $translate[jt_schedule_startsText];
			}
			else {
				$starts_text = 'Starts';
			}
		
			if (!empty ($translate[jt_schedule_durationText])) {
				$duration_text = $translate[jt_schedule_durationText];
			}
			else {
				$duration_text = 'Duration';
			}
		
			if (!empty ($translate[jt_schedule_instructorText])) {
				$instructor_text = $translate[jt_schedule_instructorText];
			}
			else {
				$instructor_text = 'Instructor';
			}
		
			if (!empty ($translate[jt_schedule_classText])) {
				$class_text = $translate[jt_schedule_classText];
			}
			else {
				$class_text = 'Class';
			}
		
			if (!empty ($translate[jt_schedule_signupText])) {
				$signup_text = $translate[jt_schedule_signupText];
			}
			else {
				$signup_text = 'Sign up';
			}
		
			if (!empty ($translate[jt_schedule_firstnameText])) {
				$firstname_text = $translate[jt_schedule_firstnameText];
			}
			else {
				$firstname_text = 'First Name';
			}
		
			if (!empty ($translate[jt_schedule_lastnameText])) {
				$lastname_text = $translate[jt_schedule_lastnameText];
			}
			else {
				$lastname_text = 'Last Name';
			}
		
			if (!empty ($translate[jt_schedule_emailText])) {
				$email_text = $translate[jt_schedule_emailText];
			}
			else {
				$email_text = 'Email';
			}
		
			if (!empty ($translate[jt_schedule_phoneText])) {
				$phone_text = $translate[jt_schedule_phoneText];
			}
			else {
				$phone_text = 'Phone Text';
			}
		
			if (!empty ($translate[jt_schedule_dayText])) {
				$day_text = $translate[jt_schedule_dayText];
			}
			else {
				$day_text = 'Day';
			}
		
			if (!empty ($translate[jt_schedule_submitText])) {
				$submit_text = $translate[jt_schedule_submitText];
			}
			else {
				$submit_text = 'Submit';
			}
		
?>