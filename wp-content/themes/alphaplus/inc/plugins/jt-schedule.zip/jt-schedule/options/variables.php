<?php

	define('jt_schedule_singlePage', 'jt_schedule_singlePage'); 

	// Translations
	define('jt_schedule_startsText', 'jt_schedule_startsText');  
	define('jt_schedule_durationText', 'jt_schedule_durationText');
	define('jt_schedule_instructorText', 'jt_schedule_instructorText');
	define('jt_schedule_classText', 'jt_schedule_classText');
	define('jt_schedule_signupText', 'jt_schedule_signupText');

	define('jt_schedule_firstnameText', 'jt_schedule_firstnameText');
	define('jt_schedule_lastnameText', 'jt_schedule_lastnameText');
	define('jt_schedule_emailText', 'jt_schedule_emailText');
	define('jt_schedule_phoneText', 'jt_schedule_phoneText');
	define('jt_schedule_dayText', 'jt_schedule_dayText');
	define('jt_schedule_submitText', 'jt_schedule_submitText');

?>